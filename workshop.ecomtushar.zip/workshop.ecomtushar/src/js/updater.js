
let updatedTime = new Date();

// Import the functions you need from the SDKs you need
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.0.0/+esm';


const supabaseUrl = 'https://bqvxtxtxwlpquzhrhztz.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJxdnh0eHR4d2xwcXV6aHJoenR6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTk0MDI5MjQsImV4cCI6MjAzNDk3ODkyNH0.ynyfW_p6plvcEZOuSlh2MsbTRDmLpfvZiTLwaERCs-M'
const supabase = createClient(supabaseUrl, supabaseKey)

// Create a Firestore reference to the document you want to retrieve

const price = document.querySelectorAll('.price')
const webinar1 = document.querySelectorAll('.webinardate1')
const webinar2 = document.querySelectorAll('.webinardate2')
const month = document.querySelectorAll(".webinarmonth")
const time = document.querySelectorAll(".webinartime")
const day = document.querySelector(".webinarday")
const ctas = document.querySelectorAll('.cta');
const whatsapp = document.querySelector('.whatsapp');
const cutprice = document.querySelectorAll('.cutprice');
const discount = document.querySelectorAll('.discount');

const getDocData = async () => {
    const { data, error } = await supabase
        .from('creators')
        .select()
        .eq('email', 'tusharthaparecom@gmail.com').eq('course', 'workshop')

    if (data) {

        // console.log(data);
        // console.log(result.price.replace(/(\d)(?=(\d\d)+\d$)/g, "$1,"));
        if (price) {
            price.forEach((item) => item.innerHTML = `₹${data[0].price?.replace(/(\d)(?=(\d\d)+\d$)/g, "$1,")}`);
        }
        if (webinar1) {
            webinar1.forEach((item) => item.innerHTML = `${convertDate(data[0].date) + getOrdinalSuffix(convertDate(data[0].date))}`)

        }
        if (webinar2) {
            webinar2.forEach((item) => item.innerHTML = `${convertDate(data[0].date) + 1 + getOrdinalSuffix(convertDate(data[0].date) + 1)}`)
        }
        if (time) {
            time.forEach((item) => item.innerHTML = convertTime(data[0].time))
        }
        if (month) {
            month.forEach((item) => item.innerHTML = convertMonth(data[0].date))
        }
        if (day) {
            day.innerHTML = convertDay(data[0].date);
        }
        if (whatsapp) {
            whatsapp.setAttribute("href", data[0].whatsapp);
        }
        if (cutprice) {
            cutprice.forEach((item) => item.innerHTML = `₹${data[0].cut_price.replace(/(\d)(?=(\d\d)+\d$)/g, "$1,")}`);
        }
        if (discount) {
            discount.forEach((item) => item.innerHTML = data[0].discount);
        }
        if (ctas) { ctas.forEach((button) => button.setAttribute("href", data[0].cta)) }

        updatedTime = `${data[0].date} ${data[0].time}`;
        setTimer();

    } else {
        console.log(error);
    }

};

// for comma genrator

// Call the function to get the document data
getDocData();


const setTimer = () => {

    // Set the date we're counting down to
    var countDownDate = new Date(`${updatedTime}`).getTime();
    // Update the count down every 1 second
    var x = setInterval(function () {
        // Get today's date and time
        var now = new Date().getTime();

        // Find the distance between now and the count down date
        var distance = countDownDate - now;

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Display the result in the element with id="demo"

        const daysContainer = document.querySelectorAll(".days-container");
        const hoursContainer = document.querySelectorAll(".hours-container");
        const minutesContainer = document.querySelectorAll(".minutes-container");
        const secondsContainer = document.querySelectorAll(".seconds-container");

        // document.getElementById('timer').innerHTML =
        //   days + 'd ' + hours + 'h ' + minutes + 'm ' + seconds + 's ';

        daysContainer.forEach((day) => {
            day.innerHTML = days;
        });
        hoursContainer.forEach((hour) => {
            hour.innerHTML = hours;
        });
        minutesContainer.forEach((minute) => {
            minute.innerHTML = minutes;
        });
        secondsContainer.forEach((second) => {
            second.innerHTML = seconds;

        });

        // If the count down is finished, write some text
        if (distance < 0) {
            clearInterval(x);
            document.getElementById("timer").innerHTML = "EXPIRED";
        }
    }, 1000);

}

const convertDate = (date) => {
    let dateObj = new Date(date);

    // Define an array of full month names


    // Extract the day and month
    let day = dateObj.getDate();


    // Format the date as "DD MMMM"
    let formattedDate = day;
    return formattedDate;
}

const convertMonth = (date) => {
    let dateObj = new Date(date);

    // Define an array of full month names
    let monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    // Extract the day and month

    let month = monthNames[dateObj.getMonth()];

    // Format the date as "DD MMMM"
    let formattedDate = `${month}`;
    return formattedDate;
}

const convertTime = (time) => {
    // Split the input time into hours and minutes
    let [hours, minutes] = time.split(':').map(Number);

    // Determine the period (AM/PM)
    let period = hours >= 12 ? 'PM' : 'AM';

    // Adjust the hours for 12-hour format
    hours = hours % 12 || 12;

    // Format the hours and minutes to ensure two digits
    let formattedHours = hours.toString().padStart(2, '0');
    let formattedMinutes = minutes.toString().padStart(2, '0');

    // Combine the formatted time
    let formattedTime = `${formattedHours}:${formattedMinutes} ${period}`;

    return formattedTime;
}

function convertDay(dateString) {
    // Parse the date string into a Date object
    const date = new Date(dateString);

    // Array of days of the week
    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    // Get the day of the week as a number (0-6)
    const dayIndex = date.getDay();
    // Return the name of the day
    return daysOfWeek[dayIndex];
}

function getOrdinalSuffix(day) {
    if (day >= 11 && day <= 13) {
        return "th";
    }
    switch (day % 10) {
        case 1: return "st";
        case 2: return "nd";
        case 3: return "rd";
        default: return "th";
    }
}